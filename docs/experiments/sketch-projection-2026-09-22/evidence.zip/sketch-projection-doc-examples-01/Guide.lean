import Leant2

set_option leant2.budgetMs 5000

#leant2_sketch f : List Nat → Nat :=
  (fun (step : Nat → Nat → Nat) (seed : Nat) (xs : List Nat) =>
    List.foldr step seed xs) ?step ?seed
where
  f [] = 1 ∧ f [2] = 3 ∧ f [2, 3] = 6 ∧ f [0, 4, 0] = 5

def offsetSum : List Nat → Nat := it1

example : offsetSum [5, 8] = 14 := by decide

#leant2_sketch identity : ∀ A : Type, A → A :=
  fun (A : Type) (value : A) => (?body : A)
where
  ∀ (A : Type) (value : A), identity A value = value
