import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
#leant2_providers
#leant2_sketch f : List Nat → Nat :=
  List.foldr Nat.add 0
where
  f [] = 1 ∧ f [2] = 3 ∧ f [2, 3] = 6 ∧ f [0, 4, 0] = 5

open Lean Elab Command in
run_cmd do
  for name in [`it, `it1] do
    if (Leant2.resultBinding? (← getEnv) name).isSome ||
        !(getAliases (← getEnv) name false).isEmpty then
      throwError "sketch negative retained a result alias: {name}"
  logInfo "SKETCH_NO_RESULT_OK"
