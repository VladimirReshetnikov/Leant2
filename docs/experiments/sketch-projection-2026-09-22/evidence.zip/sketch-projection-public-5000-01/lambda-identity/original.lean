import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
#leant2_providers
#leant2_sketch f : ∀ A : Type, A → A :=
  fun (A : Type) (value : A) => (?body : A)
where
  ∀ (A : Type) (value : A), f A value = value
def completed : ∀ A : Type, A → A := it1
theorem originalContract :
    ∀ (A : Type) (value : A), completed A value = value := by
  intro A value
  rfl

theorem heldOut : completed Nat 7 = 7 ∧ completed Bool true = true ∧
    completed (List Nat) [8, 2] = [8, 2] := by decide

#eval if completed Nat 7 == 7 && completed Bool true &&
    completed (List Nat) [8, 2] == [8, 2]
  then "SKETCH_VALUE_OK" else "SKETCH_VALUE_FAILED"

open Lean Elab Command in
run_cmd do
  for name in [``completed, ``originalContract, ``heldOut] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_lambda-identity_OK"
