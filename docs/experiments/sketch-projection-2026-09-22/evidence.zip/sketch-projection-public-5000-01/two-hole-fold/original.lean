import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
#leant2_providers
#leant2_sketch f : List Nat → Nat :=
  (fun (step : Nat → Nat → Nat) (init : Nat) (xs : List Nat) => List.foldr step init xs) ?step ?init
where
  f [] = 1 ∧ f [2] = 3 ∧ f [2, 3] = 6 ∧ f [0, 4, 0] = 5
def completed : List Nat → Nat := it1
theorem originalContract :
    completed [] = 1 ∧ completed [2] = 3 ∧ completed [2, 3] = 6 ∧
    completed [0, 4, 0] = 5 := by decide

-- Extra examples, not substitutes for the original four observations.
theorem heldOut : completed [5, 8] = 14 ∧ completed [0, 0] = 1 ∧
    completed [9, 1, 2, 3] = 16 := by decide

#eval if completed [] == 1 && completed [2, 3] == 6 &&
    completed [5, 8] == 14 && completed [9, 1, 2, 3] == 16
  then "SKETCH_VALUE_OK" else "SKETCH_VALUE_FAILED"

open Lean Elab Command in
run_cmd do
  for name in [``completed, ``originalContract, ``heldOut] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_two-hole-fold_OK"
