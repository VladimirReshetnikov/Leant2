import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
namespace FrontendCase
theorem selected (P Q : Prop) (hp : P) (h : P → Q) : Q ∧ True := by
  constructor
  · leant2
  · trivial
example (P Q : Prop) (hp : P) (h : P → Q) : Q := (selected P Q hp h).1
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.selected] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_tactic-local-proof_OK"
