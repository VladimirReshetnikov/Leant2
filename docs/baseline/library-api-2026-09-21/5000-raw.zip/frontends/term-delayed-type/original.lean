import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
namespace FrontendCase
-- The explicit implicit A is shared by both binders; separate `_` annotations
-- would leave independent holes. No result or first-argument annotation fixes A:
-- the later Nat argument must supply the delayed constraint for synthesis.
def selected := (fun {A : Type} (x y : A) => (x, y)) synth% (7 : Nat)
example : Nat × Nat := selected
example : selected.2 = 7 := rfl
-- Any well-typed first component is valid; do not assume the synthesizer selects zero.
#eval if selected.2 == 7 then "FRONTEND_VALUE_OK" else "FRONTEND_VALUE_FAILED"
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.selected] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_term-delayed-type_OK"
