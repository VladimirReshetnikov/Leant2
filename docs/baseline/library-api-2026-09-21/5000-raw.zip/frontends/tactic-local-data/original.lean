import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
namespace FrontendCase
def selected (A B : Type) (x : A) (f : A → B) : B := by
  leant2
example (A B : Type) (x : A) (f : A → B) : selected A B x f = f x := rfl
#eval if selected Nat Bool 4 (fun n => n == 4) then "FRONTEND_VALUE_OK" else "FRONTEND_VALUE_FAILED"
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.selected] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_tactic-local-data_OK"
