import Leant2
set_option leant2.budgetMs 5000
def deliberatelyRejected : False := synth%
