import Leant2
set_option leant2.budgetMs 5000
set_option linter.unusedVariables false
universe u v
namespace FrontendCase
def selected {A : Sort u} (F : A → Sort v) (x : A) (hx : F x) : F x := synth%
theorem proof (P Q : Prop) (hp : P) (h : P → Q) : Q := synth%
example {A : Sort u} (F : A → Sort v) (x : A) (hx : F x) : selected F x hx = hx := rfl
#eval if selected (fun _ : Nat => Nat) 4 17 == 17 then "FRONTEND_VALUE_OK" else "FRONTEND_VALUE_FAILED"
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.selected, ``FrontendCase.proof] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_term-local-context_OK"
