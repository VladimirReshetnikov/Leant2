import Leant2
set_option leant2.budgetMs 10000
set_option linter.unusedVariables false
namespace FrontendCase
def selected {A : Type} (F : A → Type) (x : A) (hx : F x) : F x :=
  let y := x
  (fun h : F y => let witness := h; synth%) hx
class Pick (A : Type) where
  value : A
def fromInstance (A : Type) [outer : Pick A] : A :=
  letI : Pick A := outer
  synth%
example {A : Type} (F : A → Type) (x : A) (hx : F x) : selected F x hx = hx := rfl
example (A : Type) (inst : Pick A) : @fromInstance A inst = inst.value := rfl
#eval if selected (fun _ : Nat => Nat) 8 31 == 31 && @fromInstance Nat ⟨17⟩ == 17 then "FRONTEND_VALUE_OK" else "FRONTEND_VALUE_FAILED"
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.selected, ``FrontendCase.fromInstance] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_term-lets-instances_OK"
