import Leant2
set_option leant2.budgetMs 10000
set_option linter.unusedVariables false
namespace FrontendCase
theorem checkedRejection : True := by
  fail_if_success
    have impossible : False := synth%
  trivial
end FrontendCase

open Lean Elab Command in
run_cmd do
  for name in [``FrontendCase.checkedRejection] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "frontend result has no checked value"
    if ci.type.hasMVar || ci.type.hasLevelMVar || ci.type.hasFVar || ci.type.hasSorry ||
        value.hasMVar || value.hasLevelMVar || value.hasFVar || value.hasSorry then
      throwError "frontend result contains a hole, free variable, or sorry"
    for axiomName in (← collectAxioms name) do
      unless axiomName ∈ [``propext, ``Classical.choice, ``Quot.sound] do
        throwError "frontend result uses a nonstandard axiom: {axiomName}"
  logInfo "FRONTEND_AUDIT_term-false_OK"
