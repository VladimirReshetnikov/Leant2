import Leant2
set_option leant2.budgetMs 10000
def deliberatelyRejected : False := by leant2
